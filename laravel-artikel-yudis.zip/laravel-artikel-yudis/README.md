# laravel-artikel-yudis
Artikel "Laravel Framework"

Bahasa Pemrograman :
1. Laravel
2. MySql

Fitur :
1. Menampilkan daftar artikel.
2. Pembagian Hak Akses (Admin dan User).
3. Autentikasi (User tidak dapat masuk kedalam sistem admin).
4. Admin dapat melakukan perintah CRUD artikel.

Catatan :
- Sistem menggunakan store link untuk menyimpan gambar. jadi sebelum run program diharapkan jalankan php artisan storage:link pada cmd / terminal.
